#ifndef BUTTONGROUP_H
#define BUTTONGROUP_H

#include <QWidget>
#include <QButtonGroup>
#include "button.h"
#include <QVector>
class buttonGroup : public QButtonGroup
{
    Q_OBJECT
public:
    explicit buttonGroup(QWidget *parent = nullptr);
    int doubleCounter=0;
    QVector<QString> idLetterList;
    int pairs=0;
    int tries=0;
    void twoButtonPressed();
signals:
    void updatePairsNTries(int pairs,int tries);
public slots:
    void doubleButtonChecker(bool clicked);
};

#endif // BUTTONGROUP_H
