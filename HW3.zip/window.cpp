#include "window.h"
#include "button.h"
#include "buttongroup.h"
#include "buttongroup.h"
#include <QLabel>
#include <QRandomGenerator>
#include <QVector>
#include <ctime>
#include <QTest>
window::window(QWidget *parent,int numberOfPairs) : QWidget(parent)
{
    this->numOfPairs=numberOfPairs;//this is for modularity of the code against different pair numbers but not used for this purpose
    buttonGroup1 = new buttonGroup(this);//creates a buttonGroup object
    buttonGroup1->setExclusive(false);//makes buttonGroup1 able to be pressed more than one button
    setGeometry(100,100,100*numberOfPairs,500);//sets the coordinates,height,width of the game window
    QVector<QString> letterList={"A","A","B","B","C","C","D","D","E","E","F","F","G","G","H","H","I","I","J","J","K","K","L","L","M","M","N","N","O","O","P","P","Q","Q","R","R","S","S","T","T","U","U","V","V","W","W","Y","Y","Z","Z"};
    int i=0;//to track while loop
    srand(time(nullptr));//its for random number generation seed
    while(i<numberOfPairs*2){//this loop creates all game buttons
        int temp=rand()%(numberOfPairs*2);//random number generation
        if(letterList[temp]!=nullptr){//checks is the letter already taken by another button if not enters
            button *button1=new button(this,letterList[temp]);//creates button with the letter randomly picked
            buttonGroup1->addButton(button1,i);//adds button to buttonGroup1 and indexes it.
            connect(button1,SIGNAL(clicked(bool)),buttonGroup1,SLOT(doubleButtonChecker(bool)));//connects button's clicked signal to buttonGroup's doubleButtonChecker SIGNAL.
            buttonGroup1->idLetterList[i]=letterList[temp];//this is to check if the two button's letter are same letter by index list
            button1->setGeometry((i%6)*200,(int(i/6)+1)*100,200,100);//button's coordinates and size
            letterList[temp]=nullptr;//deletes the picked letter from list
            i++;
        }
    }

    QFont newFont("Comic Sans MS", 20, true);//font of the information and reset button
    QPushButton *button1=new QPushButton("Reset",this);//reset button
    button1->setGeometry(800,0,400,100);
    button1->setFont(newFont);
    connect(button1,SIGNAL(clicked()),this,SLOT(newGame()));//connects reset button to newGame SLOT

    label1=new QLabel("Pairs: ",this);//this 4 blocks creates information row of the game in thev start(some wll be updated later)
    label1->setFrameStyle(QFrame::Panel | QFrame::Sunken);
    label1->setGeometry(0,0,200,100);
    label1->setAlignment(Qt::AlignCenter);
    label1->setFont(newFont);

    labelPairs=new QLabel("0",this);
    labelPairs->setFrameStyle(QFrame::Panel | QFrame::Sunken);
    labelPairs->setGeometry(200,0,200,100);
    labelPairs->setAlignment(Qt::AlignCenter);
    labelPairs->setFont(newFont);

    label2=new QLabel("Tries: ",this);
    label2->setGeometry(400,0,200,100);
    label2->setFrameStyle(QFrame::Panel | QFrame::Sunken);
    label2->setAlignment(Qt::AlignCenter);
    label2->setFont(newFont);

    labelTries=new QLabel("0",this);
    labelTries->setGeometry(600,0,200,100);
    labelTries->setFrameStyle(QFrame::Panel | QFrame::Sunken);
    labelTries->setAlignment(Qt::AlignCenter);
    labelTries->setFont(newFont);

    connect(buttonGroup1,SIGNAL(updatePairsNTries(int,int)),this,SLOT(updatePairsNTries(int,int)));//connects buttonGroup custom signal to window's updatePairsNTries SLOT to update game information

}
void window::showLetters(){//this function shows letters for 2000msec but doesn't used to avoid bugs
    for(int i=0; i<numOfPairs*2; i++){
        buttonGroup1->button(i)->clicked(true);
    }
    QTest::qWait(2000);
    for(int i=0; i<numOfPairs*2; i++){
        buttonGroup1->button(i)->setText("X");
    }
}
void window::updatePairsNTries(int pairs, int tries)//updates game info
{
    this->labelPairs->setText(QString::number(pairs));//this informations is created in buttonGroup object
    this->labelTries->setText(QString::number(tries));
    if(pairs==12){//win screen label
        QLabel* winningScreen=new QLabel("You Won!!!",this);
        winningScreen->setGeometry(0,100,1200,400);
        winningScreen->show();
        QFont newFont("Comic Sans MS", 130,QFont::Bold, true);
        winningScreen->setFont(newFont);
        winningScreen->setAlignment(Qt::AlignCenter);
        winningScreen->setStyleSheet("QLabel { background-color : cyan; color : blue; }");
    }
}
void window::newGame(){//creates a new window object, shows it and deletes old one.
    window *newWindow=new window();
    newWindow->setWindowTitle("Find The Pairs");
    newWindow->show();
    //newWindow->showLetters();

    this->deleteLater();
}
