#ifndef WINDOW_H
#define WINDOW_H
#include <QPushButton>
#include <QWidget>
#include <QButtonGroup>
#include "buttongroup.h"
#include <QLabel>
class window : public QWidget
{
    Q_OBJECT
private:
    buttonGroup *buttonGroup1;
public:
    int numOfPairs;
    void showLetters();
    QLabel* label1;
    QLabel* labelPairs;
    QLabel* label2;
    QLabel* labelTries;
    explicit window(QWidget *parent = nullptr,int numberOfPairs=12);
signals:
private slots:
    void updatePairsNTries(int pairs, int tries);
    void newGame();
};

#endif // WINDOW_H
