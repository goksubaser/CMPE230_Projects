#include "button.h"

button::button(QWidget *parent,QString letter) : QPushButton(parent)//button instance inherites QPushButton
{
    this->letter=letter;//secret letter of button
    setFixedSize(200,100);//sets button size
    this->setCheckable(true);//opens pressed unpressed version of QPushButton
    connect(this,SIGNAL(clicked(bool)),this,SLOT(slotButtonClicked(bool)));//connects its clicked signal to its custom SLOT slotButtonClicked to change its shown letter
    QFont newFont("Comic Sans MS",30,QFont::Bold,true);//Font of the button text
    setFont(newFont);
    setText("X");//default letter
}
void button::slotButtonClicked(bool checked){//custom SLOT
        if(checked){//if button pressed down enter
            setText(letter);//show hidden letter
        }
        else{//the else segment prevents button to be unpressed again once pressed until a second button pressed
            this->setChecked(true);
        }

}
