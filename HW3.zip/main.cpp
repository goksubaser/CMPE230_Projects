#include "mainwindow.h"
#include <QApplication>
#include "window.h"
#include "button.h"
int main(int argc, char *argv[])
{
    QApplication a(argc, argv);//creates the app
    window *window1=new window(); //creates a window instance
    window1->setWindowTitle("Find The Pairs");
    window1->show();
    //window1->showLetters();//this function is implemented to show letters in the beginning of the game but
                             //because of some bugs it created it commented but still useable.
    return a.exec();
}
