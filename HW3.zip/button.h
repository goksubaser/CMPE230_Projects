#ifndef BUTTON_H
#define BUTTON_H

#include <QPushButton>

class button : public QPushButton
{
    Q_OBJECT
public:
    explicit button(QWidget *parent = nullptr,QString letter="undef");
    QString letter;
signals:
private:
public slots:
    void slotButtonClicked(bool checked);
};

#endif // BUTTON_H
