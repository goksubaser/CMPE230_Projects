#include "buttongroup.h"
#include "button.h"
#include <QTest>
#include <QVector>
buttonGroup::buttonGroup(QWidget *parent) : QButtonGroup(parent)
{
    idLetterList.resize(24);//letter by id list
}

void buttonGroup::twoButtonPressed(){//if two button is pressed this function works
    for(int i=0; i<24;i++){//to check every button
        if(this->button(i)->isChecked()){//if button is pressed enter
            for(int j=i+1; j<24; j++){//checks the rest of the buttons
                if(this->button(j)->isChecked()){//if the second pressed button enter
                    if(this->idLetterList[i]==this->idLetterList[j]){//if the letters are the same enter
                        this->button(i)->setEnabled(false);//closes the buttons
                        this->button(j)->setEnabled(false);
                        pairs++;//increments the pairs found
                    }
                    this->button(i)->setText("X");//turns buttons to unpressed state
                    this->button(i)->setChecked(false);
                    this->button(j)->setText("X");
                    this->button(j)->setChecked(false);
                    tries++;//updates tries
                    emit updatePairsNTries(pairs,tries);//emits this signal to update pairs and tries on screen
                }
            }
        }

    }
    this->doubleCounter=0;//resets the doubleCounter
}
void buttonGroup::doubleButtonChecker(bool clicked){//checks if two buttons clicked
    if(clicked){//if clicked enter
        this->doubleCounter++;//increment double counter
        if(doubleCounter==2){//check if doubleCounter==2 which means two buttons pressed

            QTest::qWait(5);//wait 400msec, qWait is 5 for update of second button from X to its letter, rest is for prevent net input to come
            QTest::qSleep(395);

            twoButtonPressed();//function call
        }
    }
}

