import sys
import requests
from bs4 import BeautifulSoup

linkList2019Spring=["http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=ASIA&bolum=ASIAN+STUDIES",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=ASIA&bolum=ASIAN+STUDIES+WITH+THESIS",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=ATA&bolum=ATATURK+INSTITUTE+FOR+MODERN+TURKISH+HISTORY",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=AUTO&bolum=AUTOMOTIVE+ENGINEERING",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=BM&bolum=BIOMEDICAL+ENGINEERING",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=BIS&bolum=BUSINESS+INFORMATION+SYSTEMS",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=CHE&bolum=CHEMICAL+ENGINEERING",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=CHEM&bolum=CHEMISTRY",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=CE&bolum=CIVIL+ENGINEERING",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=COGS&bolum=COGNITIVE+SCIENCE",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=CSE&bolum=COMPUTATIONAL+SCIENCE+%26+ENGINEERING",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=CET&bolum=COMPUTER+EDUCATION+%26+EDUCATIONAL+TECHNOLOGY",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=CMPE&bolum=COMPUTER+ENGINEERING",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=INT&bolum=CONFERENCE+INTERPRETING",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=CEM&bolum=CONSTRUCTION+ENGINEERING+AND+MANAGEMENT",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=CCS&bolum=CRITICAL+AND+CULTURAL+STUDIES",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=EQE&bolum=EARTHQUAKE+ENGINEERING",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=EC&bolum=ECONOMICS",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=EF&bolum=ECONOMICS+AND+FINANCE",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=ED&bolum=EDUCATIONAL+SCIENCES",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=CET&bolum=EDUCATIONAL+TECHNOLOGY",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=EE&bolum=ELECTRICAL+%26+ELECTRONICS+ENGINEERING",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=ETM&bolum=ENGINEERING+AND+TECHNOLOGY+MANAGEMENT",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=ENV&bolum=ENVIRONMENTAL+SCIENCES",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=ENVT&bolum=ENVIRONMENTAL+TECHNOLOGY",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=XMBA&bolum=EXECUTIVE+MBA",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=FE&bolum=FINANCIAL+ENGINEERING",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=PA&bolum=FINE+ARTS",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=FLED&bolum=FOREIGN+LANGUAGE+EDUCATION",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=GED&bolum=GEODESY",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=GPH&bolum=GEOPHYSICS",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=GUID&bolum=GUIDANCE+%26+PSYCHOLOGICAL+COUNSELING",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=HIST&bolum=HISTORY",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=HUM&bolum=HUMANITIES+COURSES+COORDINATOR",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=IE&bolum=INDUSTRIAL+ENGINEERING",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=INCT&bolum=INTERNATIONAL+COMPETITION+AND+TRADE",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=MIR&bolum=INTERNATIONAL+RELATIONS%3aTURKEY%2cEUROPE+AND+THE+MIDDLE+EAST",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=MIR&bolum=INTERNATIONAL+RELATIONS%3aTURKEY%2cEUROPE+AND+THE+MIDDLE+EAST+WITH+THESIS",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=INTT&bolum=INTERNATIONAL+TRADE",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=INTT&bolum=INTERNATIONAL+TRADE+MANAGEMENT",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=LS&bolum=LEARNING+SCIENCES",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=LING&bolum=LINGUISTICS",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=AD&bolum=MANAGEMENT",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=MIS&bolum=MANAGEMENT+INFORMATION+SYSTEMS",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=MATH&bolum=MATHEMATICS",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=SCED&bolum=MATHEMATICS+AND+SCIENCE+EDUCATION",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=ME&bolum=MECHANICAL+ENGINEERING",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=MECA&bolum=MECHATRONICS+ENGINEERING",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=BIO&bolum=MOLECULAR+BIOLOGY+%26+GENETICS",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=PHIL&bolum=PHILOSOPHY",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=PE&bolum=PHYSICAL+EDUCATION",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=PHYS&bolum=PHYSICS",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=POLS&bolum=POLITICAL+SCIENCE%26INTERNATIONAL+RELATIONS",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=PRED&bolum=PRIMARY+EDUCATION",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=PSY&bolum=PSYCHOLOGY",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=YADYOK&bolum=SCHOOL+OF+FOREIGN+LANGUAGES",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=SCED&bolum=SECONDARY+SCHOOL+SCIENCE+AND+MATHEMATICS+EDUCATION",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=SPL&bolum=SOCIAL+POLICY+WITH+THESIS",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=SOC&bolum=SOCIOLOGY",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=SWE&bolum=SOFTWARE+ENGINEERING",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=SWE&bolum=SOFTWARE+ENGINEERING+WITH+THESIS",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=TRM&bolum=SUSTAINABLE+TOURISM+MANAGEMENT",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=SCO&bolum=SYSTEMS+%26+CONTROL+ENGINEERING",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=TRM&bolum=TOURISM+ADMINISTRATION",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=WTR&bolum=TRANSLATION",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=TR&bolum=TRANSLATION+AND+INTERPRETING+STUDIES",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=TK&bolum=TURKISH+COURSES+COORDINATOR",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=TKL&bolum=TURKISH+LANGUAGE+%26+LITERATURE",
                    "http://registration.boun.edu.tr/scripts/sch.asp?donem=2018/2019-2&kisaadi=LL&bolum=WESTERN+LANGUAGES+%26+LITERATURES"]

linkList2019Spring.sort() #to sort departments according to their code

start_semester = sys.argv[1] #to get start semester year
finish_semester = sys.argv[2] #to get finish semester year
semester_list = ["1998-Fall", "1999-Spring", "1999-Summer", "1999-Fall", "2000-Spring", "2000-Summer", "2000-Fall", "2001-Spring",
             "2001-Summer","2001-Fall","2002-Spring","2002-Summer","2002-Fall","2003-Spring","2003-Summer","2003-Fall",
             "2004-Spring","2004-Summer","2004-Fall","2005-Spring","2005-Summer","2005-Fall","2006-Spring","2006-Summer",
             "2006-Fall","2007-Spring","2007-Summer","2007-Fall","2008-Spring","2008-Summer","2008-Fall","2009-Spring",
             "2009-summer","2009-fall","2010-spring","2010-summer","2010-fall","2011-spring","2011-summer","2011-fall",
             "2012-Spring","2012-Summer","2012-Fall","2013-Spring","2013-Summer","2013-Fall","2014-Spring","2014-Summer",
             "2014-Fall","2015-Spring","2015-Summer","2015-Fall","2016-Spring","2016-Summer","2016-Fall","2017-Spring","2017-Summer",
             "2017-Fall","2018-Spring","2018-Summer","2018-Fall","2019-Spring"]
start_semester_year_index = 0
finish_semester_year_index = 0
year_list = ["1998/1999-1","1998/1999-2","1998/1999-3","1999/2000-1","1999/2000-2","1999/2000-3","2000/2001-1",
             "2000/2001-2","2000/2001-3","2001/2002-1","2001/2002-2","2001/2002-3","2002/2003-1","2002/2003-2",
             "2002/2003-3","2003/2004-1","2003/2004-2","2003/2004-3","2004/2005-1","2004/2005-2","2004/2005-3",
             "2005/2006-1","2005/2006-2","2005/2006-3","2006/2007-1","2006/2007-2","2006/2007-3","2007/2008-1",
             "2007/2008-2","2007/2008-3","2008/2009-1","2008/2009-2","2008/2009-3","2009/2010-1","2009/2010-2",
             "2009/2010-3","2010/2011-1","2010/2011-2","2010/2011-3","2011/2012-1","2011/2012-2","2011/2012-3",
             "2012/2013-1","2012/2013-2","2012/2013-3","2013/2014-1","2013/2014-2","2013/2014-3","2014/2015-1",
             "2014/2015-2","2014/2015-3","2015/2016-1","2015/2016-2","2015/2016-3","2016/2017-1","2016/2017-2",
             "2016/2017-3","2017/2018-1","2017/2018-2","2017/2018-3","2018/2019-1","2018/2019-2"]


for a in range(62): #to get start and finish semester years indexes
    if semester_list[a] == start_semester:
        start_semester_year_index = a
    if semester_list[a] == finish_semester:
        finish_semester_year_index = a

number_of_semesters = finish_semester_year_index - start_semester_year_index+1 #to get total number of semesters


totalLinks=[]

for link in linkList2019Spring: #to get all of the links that we should search data in them
    word = ""
    for x in range(start_semester_year_index,finish_semester_year_index+1):
        word = link[0:54]+year_list[x]+link[65:]
        totalLinks.append(word)


first="Dept./Prog(name),Course Code,Course Name"
for a in range(start_semester_year_index,finish_semester_year_index+1): #to get first line of output will be printed
    first=first+", " + semester_list[a]
print(first+ ", Total Offerings")


for a in range(69): #to search all the departments one by one
    courses=[] #all of the courses in that department
    totalInstructors=[] #all of the instructors in that department
    totalOfferingG=0
    totalOfferingUG=0
    codeOfDepartment=""
    DepartmentName=""

    for semester in range(number_of_semesters): #to search all of the semesters in that department
        url= totalLinks[a*number_of_semesters+semester] #url of the department for that semester
        y=url.find("&",66)
        z=url.find("=",55)
        codeOfDepartment= url[z+1:y] #to get code of the department

        DepartmentName=url[url.rfind("=")+1:] #to get name of the department
        for z in DepartmentName: #to get rid of meaningless symbols in department name
            if "%26" in DepartmentName:
                DepartmentName=DepartmentName.replace('%26','&',1)
            if "+" in DepartmentName:
                DepartmentName=DepartmentName.replace('+',' ',1)
        result = requests.get(url)
        tds = []
        if result.status_code == 200:
            source=result.content
            soup = BeautifulSoup(source, 'lxml')  #to find values that we want to find using BeautifulSoup lib.
            for tr in soup.find_all('tr'): #to search all 'tr' tags in that source code
                tdList = tr.find_all('td') #to find 'td' tags in 'tr' tags.
                tds.append(tdList) #to keep td tags
        for c in range(9, len(tds)): #to search tds
            courseCode=tds[c][0].text #to get course code
            if len(courseCode) > 2: #check if course exist or not, course code length must be greater than 2
                courseCode= courseCode[0:-4] #to get rid of section part
                instructorOfCourse = (tds[c][5].text)[0:-1] #to get course's instructor
                newCourse= True
                indexOfCourse=-1
                indexOfCourse1=-1
                if instructorOfCourse not in totalInstructors: #to check is instructor new and he is not "STAFF" , then append it totalInstructor list
                    if "STAFF" not in instructorOfCourse:
                        totalInstructors.append(instructorOfCourse)
                for course in courses: #check if it is new course or not, if it is not new course, get it's index from courses[]
                    indexOfCourse1 +=1
                    if course[0] == courseCode:
                        newCourse=False
                        indexOfCourse=indexOfCourse1
                if newCourse: #if it is new course append it to courses[]
                    courseName=tds[c][2].text[:-1]  #to get course name
                    if "STAFF" not in instructorOfCourse: #to check if course's instructor is not "STAFF"
                        courses.append([courseCode,courseName,[instructorOfCourse],[semester]])
                    else:
                        courses.append([courseCode,courseName,[],[semester]])

                else:
                    if instructorOfCourse not in courses[indexOfCourse][2]: #if it not new course and instructor is new, append the instructor to course's instructor list
                        if "STAFF" not in instructorOfCourse:
                            courses[indexOfCourse][2].append(instructorOfCourse)
                    if semester not in courses[indexOfCourse][3]:  #if it not new course add the semester to course's semester list
                        courses[indexOfCourse][3].append(semester)
    courses.sort() #to sort courses according to their codes
    graduate=0 #to get graduate course number that will be printed under course code section
    underGraduate=0 #to get under graduate course number that will be printed under course code section
    ugListOfCourses=[] #to get graduate, undergraduate course numbers and number of instructors for each semester
    for course in courses:
        courseCode=course[0]
        courseCodeNumber=courseCode[-3:] #to get 3rd char of course code from end. If it is greater than 4, course is graduate, else course is undergraduate
        if courseCodeNumber[0]=="5" or courseCodeNumber[0]=="6" or courseCodeNumber[0]=="7":
            totalOfferingG += len(course[3])
            graduate+=1
        else:
            totalOfferingUG += len(course[3])
            underGraduate+=1
    for semester in range(number_of_semesters): #to search courses semester by semester, and find graduate,underGraduate, instructor numbers for each semester.
        g=0
        uG=0
        instructorListOfSemester=[]
        for course in courses:       #to search all of the courses in that department
            if semester in course[3]: #to check if this course exist in that semester or not
                courseCode = course[0]
                courseCodeNumber = courseCode[-3:]
                if courseCodeNumber[0]=="5" or courseCodeNumber[0]=="6" or courseCodeNumber[0]=="7":
                    g += 1
                else:
                    uG += 1
                for instructor in course[2]: #to search all of the instructors for one semester. If it is new, append it to instructorListOfSemester
                    if instructor not in instructorListOfSemester:
                        instructorListOfSemester.append(instructor)
        ugListOfCourses.append([uG,g,len(instructorListOfSemester)]) #to get graduate,underGraduate, instructor numbers of course for each semester.


    if(len(courses)>0): #if departmant between start and end semesters, print the department and courses informations that should be provided in csv format.
        firstStringDep=codeOfDepartment+"("+DepartmentName+")" +",U"+ str(underGraduate) +" G"+ str(graduate)+", ,"
        for ugListOfCourse in ugListOfCourses:
            firstStringDep=firstStringDep+ "U"+str(ugListOfCourse[0])+ " G"+str(ugListOfCourse[1])+ " I"+str(ugListOfCourse[2])+","
        firstStringDep= firstStringDep + "U"+str(totalOfferingUG) + " G" +str(totalOfferingG)+ " I" + str(len(totalInstructors))
        print(firstStringDep)
        for course in courses:
            courseString= " ," + course[0] + "," + course[1] +","
            for semester in range(number_of_semesters):
                if semester in course[3]:
                    courseString= courseString + "x,"
                else:
                    courseString= courseString + " ,"
            courseString= courseString + str(len(course[3])) +"/"+ str(len(course[2]))
            print(courseString)






